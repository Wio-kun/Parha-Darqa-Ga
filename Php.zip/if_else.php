<?php

$tall = rand(1,100);

if ($tall > 50) {
    echo "$tall er større enn 50";
}elseif ($tall < 50) {
    echo "$tall er mindre enn 50";
}

?>