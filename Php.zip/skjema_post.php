<!doctype html>
<html>
<head>
    <title>Skjema</title>
    <meta charset="UTF-8">
    <style>
        th {
            width = "177px"
        }
    </style>

</head>
<body>
    <form action="skjema_get.php" method="GET">
        Navn
        <input type="text" name="Navn">
        <br>
        Inntekter
        <br>
        <tr>
            <th>2020</th>
            <th>2021</th>
            <th>2022</th>
        </tr>
        <br>
        <tr>
            <td><input type="text"></td>
            <td><input type="text"></td>
            <td><input type="text"></td>
        </tr>
</body>
