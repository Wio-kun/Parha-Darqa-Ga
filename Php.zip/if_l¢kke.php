<?php

$tall = 10;
$nummer = 42;

while ($tall <= 100) {
    if ($tall == $nummer) {
        echo "Y <br>";
        $tall = $tall + 1;
    }
    else {
        echo "X <br>";
        $tall = $tall + 1;
    }
}

?>