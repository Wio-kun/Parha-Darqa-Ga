<?php

if (isset($_GET["sendinn"])) {
    $navn = $_GET[""];
}