<?php 

include "variabler.php";
echo "<br>";
include "if_else.php";
echo "<br>";
include "if_løkke.php";
echo "<br>";
include "to_løkker.php";
echo "<br>";
